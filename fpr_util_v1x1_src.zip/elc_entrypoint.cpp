#include "elc_entrypoint.h"
#include <assert.h>
#include <memory>
#include <cctype>
#include "hxdw/hxdw_utils.h"

// TODO:
//     Symlinks

const char* szUsage =
		"\n"
		"FILE PRE-READ UTIL\n"
		"------------------\n"
		"Build: " __DATE__ "\n"
		"\n"
		"\n"
		"Pre-reads specified files by loading their binary data into\n"
		"memory. Then just exits. Typically, can be used to force\n"
		"all DLL files, in specified dir, precached off-HDD.\n"
		"\n"
		"Usage\n"
		"-------\n"
		"    program.exe [options]\n"
		"    program.exe --idn DIR [--exts EXTS] [--nBufSize NUM]\n"
		"    program.exe [--bShowReads] [--bHideFnames] [--bNoSubdirs]\n"
		"    program.exe [--bKeepData] [--bFollowDirSymlinks]\n"
		"\n"
		"    EXTS: Comma separated file extension names.\n"
		"          If first ext is a '*' then it is a blacklist (otherwise whitelist).\n"
		"          Don't add leading dot character on each ext.\n"
		"          Matching is case insensitive.\n"
		"\n"
		"";
bool fpr_AppendBytes( std::vector<uint8_t>& data3, const uint8_t* ptr, size_t num )
{
	size_t offset2 = ( data3.size() * sizeof(data3[0]) );
	data3.resize( data3.size() + num);
	uint8_t* dst = &data3[0] + offset2;
	std::memcpy( dst, ptr, num );
	return 1;
}
void fpr_ShowBytes( const uint8_t* bfr2, size_t num, const char* flags2 )
{
	for( size_t i=0; i<num; i++ ){
		printf("%s%02x", (i?",":""), bfr2[i] );
	}
	if( strchr( flags2, 'n' ) )
		printf("\n");
}
int main( int argc, const char*const* argv )
{
	std::string dir2, exts;// = ".\\";
	size_t nBufSize = 65536, nErr = 0;
	bool bHideFnames = 0, bShowReads = 0, bNoSubdirs = 0, bKeepData = 0;
	bool bFollowDirSymlinks = 0;
	bool bHlp = argc <= 1;
	if( bHlp ){
		printf( szUsage );
		return 10;
	}
	for( int i=1; i<argc; i++ ){
		bHlp = (
			!lstrcmpi( argv[i], "-h" ) || !lstrcmpi( argv[i], "-help" ) ||
			!lstrcmpi( argv[i], "--h" ) || !lstrcmpi( argv[i], "--help" ) ||
			!lstrcmpi( argv[i], "-?" ) || !lstrcmpi( argv[i], "/?" ) );
		if( bHlp ){
			printf( szUsage );
			return 10;
		}else if( !lstrcmpi( argv[i], "--idn" ) ){
			if( i+1 < argc ){
				dir2 = argv[++i];
			}
		}else if( !lstrcmpi( argv[i], "--exts" ) ){
			if( i+1 < argc ){
				exts = argv[++i];
			}
		}else if( !lstrcmpi( argv[i], "--nBufSize" ) ){
			if( i+1 < argc ){
				nBufSize = static_cast<size_t>( atoi( argv[++i] ) );
			}
		}else if( !lstrcmpi( argv[i], "--bShowReads" ) ){
			bShowReads = 1;
		}else if( !lstrcmpi( argv[i], "--bHideFnames" ) ){
			bHideFnames = 1;
		}else if( !lstrcmpi( argv[i], "--bNoSubdirs" ) ){
			bNoSubdirs = 1;
		}else if( !lstrcmpi( argv[i], "--bKeepData" ) ){
			bKeepData = 1;
		}else if( !lstrcmpi( argv[i], "--bFollowDirSymlinks" ) ){
			bFollowDirSymlinks = 1;
		}
	}
	if( dir2.empty() ){
		printf("ERROR: no input directory. see '--idn DIR' [KutgK0bY]\n");
		return 2;
	}
	bool bExtsAreBlacklist = 0;
	std::vector<std::string> exts2;
	if( !exts.empty() ){
		hxdw_StrExplode( exts.c_str(), exts2, {",",}, -1, "\r\n\x20\t" );
		if( exts2.empty() ){
			printf("ERROR: list of file extensions yields exmpty set, see '--exts TEXT'\n");
			return 3;
		}
		for( auto& a : exts2 ){
			std::transform( a.begin(), a.end(), a.begin(), [](uint8_t c){ return std::tolower(c); } );
		}
		if( exts2[0] == "*" ){
			exts2.erase( exts2.begin() );
			bExtsAreBlacklist = 1;
		}
	}else{
		exts2.clear();
		bExtsAreBlacklist = 1;
	}
	std::vector<std::string> fnames3;
	{
		std::vector<std::string> fnames2;
		{
			std::string srFlg("f");
			srFlg += ( bNoSubdirs ? "" : "r" );
			srFlg += ( !bFollowDirSymlinks ? "y" : "" );
			bool rs2 = hxdw_GetDirFilesRcv( dir2.c_str(), fnames2, srFlg.c_str() );
			if( !rs2 ){
				printf("ERROR: directory scan failed [cnn0dlep]\n");
				return 3;
			}
		}
		std::vector<std::string>::iterator b;
		for( b = fnames2.begin(); b != fnames2.end(); ++b ){
			auto& a = *b;
			std::string  ext2 = hxdw_SplitExt( hxdw_SplitPath(a).second ).second;
			std::transform( ext2.begin(), ext2.end(), ext2.begin(), [](uint8_t c){ return std::tolower(c); } );
			bool bFound = ( std::find( exts2.begin(), exts2.end(), ext2 ) != exts2.end() );
			if( bFound && !bExtsAreBlacklist ){ //if whitelist mode.
				fnames3.push_back(a);
			}
			if( !bFound && bExtsAreBlacklist ){ //if blacklist mode.
				fnames3.push_back(a);
			}
		}
	}
	if( fnames3.empty() ){
		printf("INFO: no files to scan.\n");
		return 0;
	}
	{
		size_t nread, nFnmLenMax = 0;
		std::vector<uint8_t> bfr3( nBufSize, 0 );
		{
			for( const auto& a : fnames3 ){
				nFnmLenMax = std::max<size_t>( a.size(), nFnmLenMax );
			}
			nFnmLenMax = std::min<size_t>( 42, nFnmLenMax );
		}
		char fmt2[256] = ""; int ii2 = 0;
		sprintf_s( fmt2, sizeof(fmt2), "%%d/%%d Reading: [%%%ds]\n", int(nFnmLenMax) );
		std::vector<uint8_t> data2;
		std::vector<std::string>::iterator b;
		for( b = fnames3.begin(); b != fnames3.end(); ++b, ii2++ ){
			const auto& a = *b;
			if( !bHideFnames )
				printf( fmt2, ii2+1, int(fnames3.size()), hxdw_StrLTruncate( a.c_str(), nFnmLenMax ).c_str() );
			std::FILE* hf2 = std::fopen( a.c_str(), "rb" );
			if( hf2 ){
				std::fseek( hf2, 0, SEEK_SET );
				size_t offset3 = 0;
				while( (nread = fread( &bfr3[0], 1, nBufSize, hf2)) > 0 ){
					if( bShowReads ){
						printf("INFO: Read %llu bytes at %llu\n", nread, offset3 );
						//fpr_ShowBytes( &bfr3[0], std::min<size_t>( 16, nread ), "n");
					}
					fpr_AppendBytes( data2, &bfr3[0], nread );
					if( std::fseek( hf2, offset3+nread, SEEK_SET ) ) // if failed.
						break;
					offset3 += nread;
				}
				if( ferror(hf2) ){
					printf("WARN: failed reading file data at %llu. ('%s')\n", offset3, hxdw_SplitPath(a).second.c_str() );
					nErr++;
				}
				std::fclose(hf2);
				hf2 = 0;
			}else{
				printf("WARN: file open failed. ('%s')\n", hxdw_SplitPath(a).second.c_str() );
				nErr++;
			}
			if( !bKeepData ){
				data2.clear();
				data2.shrink_to_fit();
			}
		}
	}
	printf("Done (warnings:%d)\n", int(nErr) );
	return 0;
}

